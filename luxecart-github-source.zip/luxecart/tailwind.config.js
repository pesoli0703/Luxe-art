/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#242520',
        muted: '#65685e',
        paper: '#ffffff',
        sand: '#f3f0e9',
        oat: '#e8e1d5',
        line: '#e7e6e0',
        olive: '#56634b',
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        display: ['Cormorant Garamond', 'Georgia', 'serif'],
      },
      maxWidth: { site: '1440px' },
      animation: { 'fade-up': 'fadeUp .55s ease-out both' },
      keyframes: { fadeUp: { from: { opacity: '0', transform: 'translateY(12px)' }, to: { opacity: '1', transform: 'translateY(0)' } } },
    },
  },
  plugins: [],
};
