# LUXECART — Premium Fashion & Lifestyle Concept Store

A complete, responsive e-commerce demonstration built with **React, TypeScript, Vite and Tailwind CSS**. LUXECART is a fictional brand; the storefront is a working front-end demo with local cart persistence and a clearly labelled, payment-free checkout.

> **Demo boundaries:** no real payments are processed, no card details are requested, no products are shipped, and contact/newsletter forms do not transmit or store personal information.

## Quick start

Requires **Node.js 20.19+ or 22.12+** and npm.

```bash
npm install
npm run dev
```

Open the URL printed by Vite (usually `http://localhost:5173`). The dev server binds to `0.0.0.0` for container/preview environments.

```bash
npm run build      # Type-check and create a production build in dist/
npm run preview    # Serve the production build locally
npm run typecheck  # TypeScript only
npm test           # Playwright end-to-end + accessibility checks
npm run screenshots
```

For a fresh machine, install the test browser once:

```bash
npx playwright install chromium
# On Linux, if system libraries are missing:
npx playwright install-deps chromium
```

## What is included

- **7 core pages:** Home, Shop, Product Details, Cart, Checkout, About, Contact — plus order confirmation and a 404 page.
- **16 demo products** across Clothing, Shoes, Bags and Accessories, with local photography, prices, descriptions, materials, colours, sizes and stock states.
- **Product discovery:** global search dialog, collection search, category filters, price filters, in-stock filter, five sorting options, shareable filter URLs and empty states.
- **Product details:** colour/size selection, required-size validation, size guide, quantity selector, expandable photography, material/care and shipping accordions, related products.
- **Cart:** add/remove, quantity changes, variant-aware line items, stock limits, automatic subtotal/shipping/total calculations, free-shipping progress, clear-bag confirmation and `localStorage` persistence.
- **Demo checkout:** validated contact/delivery form, sample-details helper, standard/express delivery, explicit demo consent, order confirmation and printable non-personal receipt.
- **Responsive UX:** mobile navigation drawer, mobile filter drawer, sticky header, keyboard-accessible dialogs, reduced-motion support and responsive layouts from 320px upward.
- **Quality checks:** Playwright tests for shopping flows, persistence, validation, privacy, overflow and automated accessibility checks on key pages.

## Demo data and money

Prices are stored as **integer USD cents** to avoid floating-point totals. Example rules:

| Rule | Value |
| --- | --- |
| Standard shipping | $8.00 |
| Free standard shipping | Orders of $150.00+ |
| Express shipping | $18.00 |
| Tax | $0.00 (demo only) |
| Per-variant cart limit | 10, or available stock if lower |

Cart keys combine product ID, size and colour, so different variants remain separate. Saved carts are validated against the current catalog on load; unknown products, invalid variants and excessive quantities are sanitized.

## Privacy and storage

- `localStorage` key `luxecart:cart:v1` stores only product IDs, variants and quantities.
- Checkout/contact values stay in React memory and are cleared after a successful demo submission. They are never sent to a server.
- A successful checkout stores a **non-personal** receipt in `sessionStorage` (`luxecart:demo-receipt:v1`) so the confirmation survives a refresh during the session.
- Newsletter sign-up is simulated; no email address is stored or sent.
- No analytics, advertising cookies or payment provider is configured.

## Project structure

```text
luxecart/
├── public/
│   ├── images/            # Local reference photography
│   ├── favicon.svg
│   └── _redirects         # Netlify SPA fallback
├── src/
│   ├── components/        # Header, footer, dialogs, product card, summaries, fields
│   ├── context/           # Cart provider, persistence, toast notifications
│   ├── data/              # Typed product catalog and category metadata
│   ├── lib/               # Cart math, storage sanitization, receipt parsing, validation
│   ├── pages/             # Route-level screens
│   ├── App.tsx            # Routes
│   ├── main.tsx           # Entry point and local font imports
│   └── styles.css         # Tailwind layers + editorial design system
├── tests/                 # Playwright end-to-end and accessibility tests
├── screenshots/           # Desktop and mobile captures
├── docs/                  # Deployment, case study, testing and image credits
├── netlify.toml
├── vercel.json
└── package.json
```

## Design system

- **Palette:** white, near-black ink, warm sand/oat neutrals, muted olive accents.
- **Typography:** Cormorant Garamond for editorial headlines; DM Sans for UI and body text. Fonts are bundled locally via Fontsource.
- **Layout:** photography-led hero, category edit, product grid, sticky order summaries, generous whitespace and restrained motion.
- **Icons:** Lucide React.

## Deployment

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md). Netlify and Vercel configurations are included. The production output is a static `dist/` folder with an SPA fallback.

For GitHub, see [`docs/GITHUB-LAUNCH.md`](docs/GITHUB-LAUNCH.md). A GitHub Actions workflow is included at `.github/workflows/deploy-pages.yml` to build and deploy to GitHub Pages, including the correct project-site base path and SPA fallback.

## Testing

See [`docs/TESTING.md`](docs/TESTING.md). The suite covers desktop and mobile Chromium, including the complete add-to-cart → checkout → confirmation journey.

## Portfolio case study

An Upwork-ready case study is provided in [`docs/Upwork-Case-Study.md`](docs/Upwork-Case-Study.md) and as a formatted Word document, `docs/Upwork-Case-Study.docx`.

## Photography and licensing

Code is released under the MIT License. Photography is reference imagery from Unsplash and Pexels and is **not** covered by the code license. See [`docs/IMAGE-CREDITS.md`](docs/IMAGE-CREDITS.md). Replace reference photography with your own licensed product images before using this concept for a real commercial store.
