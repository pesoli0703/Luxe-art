# Photography Credits

LUXECART is a fictional, non-commercial concept. Photography is used as visual reference only. Product names, specifications and prices are illustrative, and LUXECART is not affiliated with the brands or photographers pictured.

Before commercial use, replace these references with your own licensed product photography.

## Pexels

Pexels license: https://www.pexels.com/license/

| Local file | Source |
| --- | --- |
| `hero.jpg` | https://www.pexels.com/photo/stylish-woman-wearing-a-beige-trench-coat-9968540/ (image asset 9968536) |
| `clothing-sweater.jpg` | https://www.pexels.com/photo/a-woman-in-knit-sweater-hugging-self-5709914/ (image asset 6630834) |
| `shoes-mule.jpg` | https://www.pexels.com/photo/high-heels-on-floor-22500809/ |
| `shoes-boot.jpg` | https://www.pexels.com/photo/a-person-wearing-brown-leather-boots-11326180/ (image asset 16195409) |
| `bag-shoulder.jpg` | https://www.pexels.com/search/leather+handbag/ (image asset 27174573) |

## Unsplash

Unsplash license: https://unsplash.com/license

| Local file | Source image |
| --- | --- |
| `campaign.jpg`, `clothing-blazer.jpg` | https://images.unsplash.com/photo-1625519205691-1b6b7b24622e |
| `clothing-tee.jpg` | https://images.unsplash.com/photo-1521572163474-6864f9cf17ab |
| `clothing-shirt.jpg` | https://images.unsplash.com/photo-1598033129183-c4f50c736f10 |
| `shoes-sneaker.jpg` | https://images.unsplash.com/photo-1600269452121-4f2416e55c28 |
| `shoes-loafer.jpg` | https://images.unsplash.com/photo-1533867617858-e7b97e060509 |
| `bag-tote.jpg` | https://images.unsplash.com/photo-1584917865442-de89df76afd3 |
| `bag-backpack.jpg` | https://images.unsplash.com/photo-1553062407-98eeb64c6a62 |
| `bag-clutch.jpg` | https://images.unsplash.com/photo-1590874103328-eac38a683ce7 |
| `acc-sunglasses.jpg` | https://images.unsplash.com/photo-1572635196237-14b3f281503f |
| `acc-watch.jpg` | https://images.unsplash.com/photo-1524805444758-089113d48a6d |
| `acc-jewelry.jpg` | https://images.unsplash.com/photo-1611652022419-a9419f74343d |
| `acc-bracelet.jpg` | https://images.unsplash.com/photo-1611085583191-a3b181a88401 |

## Fonts and icons

- DM Sans and Cormorant Garamond are bundled locally through Fontsource under their respective open font licenses.
- Icons: Lucide (ISC License).
