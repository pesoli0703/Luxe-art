# LUXECART — Premium Fashion & Lifestyle E-commerce Concept

**Portfolio case study · Self-initiated concept project**

**Role:** E-commerce developer & UI/UX designer  
**Stack:** React, TypeScript, Tailwind CSS, Vite, React Router, Local Storage, Playwright  
**Deliverables:** Responsive storefront, working demo cart/checkout, source code, README, deployment guide, desktop/mobile screenshots, automated tests

---

## 1. Project overview

LUXECART is a fictional fashion and lifestyle brand created to demonstrate how a premium online store can feel calm, editorial and effortless while still supporting a complete shopping journey.

The goal was not to produce a static mockup. It was to build a working storefront that a business owner could explore: search the collection, filter by category, inspect product details, add variants to a bag, adjust quantities, complete a validated demo checkout and receive an order confirmation.

The project is intentionally transparent about its boundaries. Checkout is labelled as a demonstration, no payment provider is configured, no card details are requested, and no products are shipped.

## 2. The challenge

Fashion e-commerce has to balance two things that often pull in opposite directions:

1. **Brand atmosphere** — large photography, refined typography, whitespace and a distinct point of view.
2. **Commercial clarity** — obvious product information, predictable filters, trustworthy cart math and a checkout that never surprises the shopper.

The challenge was to create a minimalist interface that still felt complete and functional, rather than decorative. Every primary shopping interaction needed to work, including edge cases such as missing sizes, sold-out products, corrupted saved carts and empty checkout states.

## 3. Design approach

### Visual direction

The design uses a restrained palette of white, near-black ink and warm sand/oat neutrals. Cormorant Garamond provides editorial headlines, while DM Sans keeps the interface legible and modern. Photography leads the hierarchy; UI chrome stays quiet.

Key screens include:

- A split editorial homepage with a clear primary call to action.
- A category edit that lets shoppers enter the collection by intent.
- Product cards with hover quick-add on desktop and always-visible actions on mobile.
- A product detail page with variant selection, size guide and expandable details.
- Sticky order summaries that keep totals visible during checkout.

### UX decisions

- **Search is available globally** and within the collection, with shareable URL state.
- **Filters are explicit**: category, price range and availability are visible and removable.
- **Size is required before adding apparel/footwear**, preventing ambiguous cart items.
- **Cart lines are variant-aware**, so the same product in two sizes remains two lines.
- **Free-shipping progress** gives shoppers a clear, non-pushy incentive.
- **Demo checkout uses sample details** so reviewers can test quickly without entering personal information.
- **Mobile navigation and filters use drawers**, keeping the small-screen interface focused.

## 4. Functional scope

### Pages

Home, Shop, Product Details, Shopping Cart, Checkout, About, Contact, Order Confirmation and a 404 page.

### Catalog

16 realistic demonstration products across four categories:

- Clothing
- Shoes
- Bags
- Accessories

Each product includes a name, USD price, description, reference photograph, material/care notes, colour options, size options and stock state.

### Shopping interactions

- Product search and category filtering
- Price and availability filtering
- Five sorting options
- Product detail navigation and related products
- Colour/size selection and required-size validation
- Add to bag, remove from bag and quantity changes
- Automatic subtotal, shipping and total calculations
- Cart persistence with local storage
- Stock caps and saved-cart sanitization
- Validated demo checkout with standard/express delivery
- Order confirmation and printable demo receipt
- Mobile navigation and mobile filter drawer
- Simulated contact and newsletter forms with clear privacy notes

## 5. Technical approach

The application is a static React SPA built with Vite and TypeScript. Tailwind CSS provides the utility foundation, while a small editorial stylesheet handles the bespoke layout, typography and responsive behavior.

### State and data

- Product data is typed and centralized in `src/data/products.ts`.
- Cart state lives in a React context provider.
- Money is stored in integer cents to avoid floating-point errors.
- Cart items are keyed by product ID, size and colour.
- Saved carts are validated against the catalog before use.
- Checkout and contact values remain in memory and are not persisted or transmitted.
- A successful checkout stores only a non-personal receipt in session storage.

### Quality and accessibility

- Playwright tests cover desktop and mobile shopping flows.
- Automated axe checks run against key pages for WCAG 2 A/AA and 2.1 AA tags.
- Dialogs support Escape, focus trapping and focus return.
- Forms expose labels, invalid states and error messages.
- Reduced-motion preferences are respected.
- Layouts are checked for horizontal overflow from 320px to 1440px.

## 6. Results

This is a portfolio concept, so the results are capability-based rather than fabricated commercial metrics.

- **7 core pages** plus confirmation and 404 states
- **16 products** across **4 categories**
- **28 passing functional/accessibility checks** across desktop and mobile projects, with mobile-only/desktop-only checks skipped where appropriate
- **18 desktop/mobile screenshots** covering the main shopping journey
- **0 payment fields** and **0 real charges**
- Complete source, documentation and deployment configuration

The final result is a storefront that demonstrates both visual design taste and practical e-commerce engineering: discovery, product detail, cart state, checkout validation, confirmation and responsive behavior all work together.

## 7. What this demonstrates for clients

- I can translate a brand direction into a coherent, responsive storefront.
- I can build functional shopping interactions, not just static screens.
- I can handle cart state, persistence, validation and edge cases cleanly.
- I can make demo boundaries explicit and avoid misleading payment flows.
- I can deliver documentation, screenshots and deployment instructions that make a project easy to review and hand off.

## 8. Next steps for a production store

For a real business, the next phase would add a commerce backend, licensed product photography, inventory management, a genuine payment provider, transactional email, tax/shipping rules, analytics consent and production privacy/terms pages.

---

## Upwork portfolio copy

**Title:** LUXECART — Premium Fashion E-commerce Store in React & TypeScript

**Short description:** A responsive fashion and lifestyle storefront with product search, category filters, variant-aware cart, local-storage persistence, validated demo checkout and order confirmation. Designed with a premium minimalist editorial aesthetic and built with React, TypeScript and Tailwind CSS.

**Tags:** E-commerce Development, React, TypeScript, Tailwind CSS, UI/UX Design, Responsive Design, Shopping Cart, Front-End Development, Web Application, Landing Page

**Project type:** Self-initiated portfolio concept

**Note for reviewers:** This is a demonstration store. No real payments are processed and no personal payment information is collected.
