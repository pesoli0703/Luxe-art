# Launch LUXECART on GitHub + GitHub Pages

This project includes a GitHub Actions workflow at `.github/workflows/deploy-pages.yml`. Once the repository is on GitHub and Pages is set to **GitHub Actions**, every push to `main` builds and deploys the storefront.

## What you need

- A GitHub account.
- A new repository, recommended name: `luxecart`.
- For a free public portfolio site, make the repository **Public**.
- Git installed locally, or use GitHub Desktop / the GitHub web uploader.

> Do not paste GitHub passwords or personal access tokens into chat. Authenticate only through GitHub’s official sign-in, Git Credential Manager, GitHub CLI, or SSH.

## Option A — Push with Git

1. Create an empty GitHub repository named `luxecart`.
   - Do **not** add a README, .gitignore, or license if you are pushing this existing project.
2. From the project folder:

```bash
cd luxecart
git init
git add .
git commit -m "Launch LUXECART storefront"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/luxecart.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. If you use SSH:

```bash
git remote add origin git@github.com:YOUR_USERNAME/luxecart.git
```

3. On GitHub, open the repository.
4. Go to **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **GitHub Actions**.
6. Open the **Actions** tab and wait for **Deploy LUXECART to GitHub Pages** to finish.
7. Your live URL will usually be:

```text
https://YOUR_USERNAME.github.io/luxecart/
```

If you named the repository `YOUR_USERNAME.github.io`, the URL will usually be:

```text
https://YOUR_USERNAME.github.io/
```

## Option B — Upload through GitHub without Git

1. Create a new repository named `luxecart`.
2. Extract `luxecart-complete.zip`.
3. Upload the **contents** of the `luxecart` folder, including the hidden `.github` folder.
   - Important: `.github/workflows/deploy-pages.yml` must be at the repository root under `.github/workflows/`.
   - Do not upload `node_modules`, `dist`, `test-results`, or `playwright-report`.
4. Commit the upload to `main`.
5. Go to **Settings → Pages → Source: GitHub Actions**.
6. Wait for the workflow in the **Actions** tab.

If your OS hides `.github`, enable “show hidden files” before uploading, or use Git/GitHub Desktop instead.

## Option C — GitHub Desktop

1. Create the empty repository on GitHub.
2. In GitHub Desktop: **File → Add local repository** and choose the `luxecart` folder.
3. If prompted, create a repository there.
4. Commit all files with message `Launch LUXECART storefront`.
5. Publish/push to `main`.
6. Enable **Settings → Pages → GitHub Actions**.

## How the deployment works

The workflow:

1. Installs dependencies with `npm ci`.
2. Detects whether this is a project Pages site (`/luxecart/`) or a user/site repository (`/`).
3. Builds with the correct Vite base path.
4. Copies `index.html` to `404.html` so client-side routes such as `/shop` and `/product/...` work on GitHub Pages.
5. Uploads `dist/` and deploys it to GitHub Pages.

## Manual re-deploy

If you need to trigger a deployment without changing code:

1. Open **Actions**.
2. Select **Deploy LUXECART to GitHub Pages**.
3. Click **Run workflow**.

## Troubleshooting

### Actions does not run
- Confirm the workflow file is at `.github/workflows/deploy-pages.yml`.
- Confirm you pushed to `main`.
- Confirm **Settings → Pages → Source** is **GitHub Actions**.

### 404 on the live site
- Wait for the workflow to finish.
- For a repository named `luxecart`, use `https://YOUR_USERNAME.github.io/luxecart/`, not `https://YOUR_USERNAME.github.io/`.
- Check **Settings → Pages** for the exact published URL.

### Blank page or missing images
- The workflow must build with `VITE_BASE_PATH` matching the repository path.
- Do not manually upload a local `dist/` built at `/` into a project Pages site unless you rebuild with the correct base path.

### Routes refresh to a GitHub 404
- The workflow copies `dist/index.html` to `dist/404.html`. Re-run the workflow if that file is missing.

### Private repository
- GitHub Pages availability for private repositories depends on your GitHub plan. For a portfolio demo, a public repository is simplest.

## After launch

Update the README and Upwork case study with your live URL:

```text
Live demo: https://YOUR_USERNAME.github.io/luxecart/
Repository: https://github.com/YOUR_USERNAME/luxecart
```
