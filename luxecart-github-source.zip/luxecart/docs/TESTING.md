# Testing & Quality Notes

## Run the suite

```bash
npm install
npx playwright install chromium
npm test
```

The Playwright config starts Vite automatically if a server is not already running on port 5173.

## Projects

| Project | Viewport | Notes |
| --- | --- | --- |
| desktop | 1440 × 1000 | Chromium desktop |
| mobile | 390 × 844 | iPhone 13 descriptor, Chromium engine, touch enabled |

## Coverage

- Homepage and category navigation
- Local image loading and absence of runtime page errors on the homepage
- Collection search, no-results state, category/price/stock filters and sorting
- Global search dialog, product navigation and Escape-to-close focus return
- Required-size validation, colour/size variants and quantity changes
- Cart persistence after refresh, removal and clear-bag confirmation
- Separate cart lines for different sizes
- Stock caps and corrupted/unknown saved-cart sanitization
- Sold-out product disabled state and empty-checkout redirect
- Checkout validation, sample details, express shipping totals and demo consent
- Order confirmation, cart clearing, receipt refresh and absence of personal data in browser storage
- Free-shipping threshold
- Contact and newsletter validation with simulated submission
- Mobile navigation and mobile filter drawer
- Size guide and product accordions
- 404 route
- Horizontal overflow checks at 320, 390, 768, 1024 and 1440px
- Automated axe accessibility checks (WCAG 2 A/AA and 2.1 AA tags) on Home, Shop, Product and Contact
- Desktop/mobile screenshot capture

## Useful commands

```bash
npm test -- --grep-invert '@capture'   # Functional + accessibility checks
npm test -- --grep @a11y               # Accessibility only
npm run screenshots                    # Regenerate desktop/mobile screenshots
npx playwright show-report             # Open the HTML report after a run
```

## Manual QA checklist

- [ ] Keyboard-only: skip link, header search, dialogs, filters, size selection and checkout.
- [ ] Screen reader: dialog labels, form errors, cart count and live toast announcements.
- [ ] Reduced motion: enable OS reduced-motion preference and confirm animations are minimized.
- [ ] Storage disabled: confirm the cart still works in memory and shows a warning.
- [ ] Slow network: confirm local images/fonts and lazy-loaded product images behave gracefully.
- [ ] Real devices: verify iOS Safari and Android Chrome in addition to Chromium emulation.

## Known demo limitations

- No backend, real inventory, payment, email or order fulfilment.
- Product photography is illustrative reference imagery, not a manufactured LUXECART catalog.
- Accessibility tests are automated checks, not a substitute for a full manual audit.
- Cross-browser validation beyond Chromium was not part of the automated suite.
