# Deployment Guide

LUXECART is a static React single-page application. Build once, then host the `dist/` folder on any static host with an SPA fallback to `index.html`.

## 1. Build locally

```bash
npm ci
npm run build
npm run preview
```

The production files are written to `dist/`. Verify the preview before uploading.

## 2A. Netlify

### Option A — Git-based deploy

1. Push this project to a GitHub/GitLab/Bitbucket repository.
2. In Netlify, choose **Add new site → Import an existing project**.
3. Select the repository.
4. Use:
   - **Base directory:** repository root (or `luxecart` if the project is in a subfolder)
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Deploy. `netlify.toml` and `public/_redirects` provide the SPA fallback.

### Option B — Drag and drop

1. Run `npm run build`.
2. Open Netlify Drop and upload the **contents of `dist/`** (or the `dist` folder).
3. The included `_redirects` file handles client-side routes.

## 2B. Vercel

1. Push the project to a Git repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Deploy. `vercel.json` rewrites non-file routes to `index.html`.

If the project lives in a monorepo/subfolder, set the Vercel **Root Directory** to the folder containing `package.json`.

## 2C. Any static host / VPS

Upload `dist/` and configure your server to serve existing files first, then fall back to `/index.html` for unknown paths.

Example Nginx location block:

```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

Example Caddyfile:

```caddyfile
example.com {
  root * /var/www/luxecart/dist
  try_files {path} /index.html
  file_server
}
```

## 3. Post-deploy checklist

- [ ] Home, Shop, Product, Cart, Checkout, About and Contact load directly by URL.
- [ ] Refreshing `/product/soft-knit-sweater` does not return a host 404.
- [ ] Product images and fonts load from the deployed origin.
- [ ] Add to cart, refresh, and confirm the bag persists.
- [ ] Complete a demo checkout and confirm the receipt appears.
- [ ] Confirm the checkout still says **demo** and no payment provider is configured.
- [ ] Test at 390px and 1440px widths.

## Environment variables

None are required. There is no backend, API key or payment secret in this demo.

## Going live for a real business

This project is intentionally front-end only. Before accepting real orders:

1. Replace fictional products, policies and reference photography with licensed business assets.
2. Add a backend or commerce platform for products, inventory and orders.
3. Integrate a genuine payment provider (for example Stripe Checkout) **server-side**; never collect raw card details in this demo.
4. Add server-side validation, tax/shipping rules, order webhooks, authentication and admin tooling.
5. Add privacy/terms pages, analytics consent where required, and transactional email.
6. Remove or rewrite all demo notices only after the real commerce flow is configured and tested.

## GitHub Pages

A ready-to-run workflow is included at `.github/workflows/deploy-pages.yml`.

1. Push this project to a GitHub repository, recommended name `luxecart`.
2. Go to **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push to `main`, or manually run **Deploy LUXECART to GitHub Pages** from the Actions tab.
4. Open the published URL, usually `https://YOUR_USERNAME.github.io/luxecart/`.

The workflow automatically sets the Vite base path for project Pages sites, copies `index.html` to `404.html` for client-side routes, and deploys `dist/`.

Full step-by-step instructions: [`GITHUB-LAUNCH.md`](GITHUB-LAUNCH.md).
