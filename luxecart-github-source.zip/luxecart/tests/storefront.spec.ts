import { expect, test } from '@playwright/test';
import type { Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

async function addSweater(page: Page, size = 'M', color = 'Oat') {
  await page.goto('/product/soft-knit-sweater');
  await page.getByRole('button', { name: `Colour: ${color}`, exact: true }).click();
  await page.getByRole('button', { name: size, exact: true }).click();
  await page.getByRole('button', { name: /Add to bag/ }).click();
}

test('homepage, category navigation and all local photographs load', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Less, but better.' })).toBeVisible();
  await expect(page.getByTestId('product-card')).toHaveCount(4);
  await page.getByRole('link', { name: /03 Bags 4 considered pieces/ }).click();
  await expect(page).toHaveURL(/category=Bags/);
  await expect(page.getByTestId('product-card')).toHaveCount(4);
  await expect(page.getByRole('heading', { name: 'Bags, considered.' })).toBeVisible();
  expect(errors).toEqual([]);
});

test('search, category, price, stock and sorting filters work together', async ({ page }) => {
  await page.goto('/shop');
  await expect(page.getByTestId('product-card')).toHaveCount(16);
  await page.getByLabel('Search the collection').fill('leather');
  await expect(page.getByTestId('product-card')).toHaveCount(8);
  await page.getByLabel('Search the collection').fill('zzzz-no-product');
  await expect(page.getByRole('heading', { name: 'No pieces found. Yet.' })).toBeVisible();
  await page.getByRole('button', { name: 'Explore all pieces', exact: true }).click();
  await expect(page).toHaveURL(/\/shop$/);
  await expect(page.getByTestId('product-card')).toHaveCount(16);
  await page.getByRole('combobox', { name: 'Sort products' }).selectOption('price-asc');
  await expect(page).toHaveURL(/sort=price-asc/);
  await expect(page.getByTestId('product-card').first()).toContainText('Essential Cotton Tee');
  await page.getByRole('combobox', { name: 'Sort products' }).selectOption('price-desc');
  await expect(page.getByTestId('product-card').first()).toContainText('Heritage Chelsea Boot');
  await page.goto('/shop?category=Accessories&available=1');
  await expect(page.getByTestId('product-card')).toHaveCount(3);
  await expect(page.getByTestId('product-card')).not.toContainText(['Everyday Leather Watch']);
  await page.goto('/shop?price=under-100');
  await expect(page.getByTestId('product-card')).toHaveCount(6);
  await page.reload();
  await expect(page.getByTestId('product-card')).toHaveCount(6);
});

test('global search opens a product and Escape closes the dialog', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Search products' }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.getByRole('searchbox', { name: 'Search products', exact: true }).fill('sweater');
  await page.getByRole('link', { name: /Soft Knit Sweater Clothing/ }).click();
  await expect(page).toHaveURL(/product\/soft-knit-sweater/);
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'Search products' }).click();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Search products' })).toBeFocused();
});

test('size validation, variants, quantity, persistence and removal', async ({ page }) => {
  await page.goto('/product/soft-knit-sweater');
  await page.getByRole('button', { name: /Add to bag/ }).click();
  await expect(page.getByText('Choose your size to make it yours.')).toBeVisible();
  await page.getByRole('button', { name: 'Colour: Charcoal', exact: true }).click();
  await page.getByRole('button', { name: 'M', exact: true }).click();
  await page.getByRole('button', { name: 'Increase quantity', exact: true }).click();
  await page.getByRole('button', { name: /Add to bag/ }).click();
  await expect(page.getByTestId('cart-count')).toHaveText('2');
  await page.reload();
  await expect(page.getByTestId('cart-count')).toHaveText('2');
  await page.goto('/cart');
  await expect(page.getByTestId('cart-line')).toContainText('Charcoal / Size M');
  await expect(page.getByTestId('subtotal')).toHaveText('$236.00');
  await page.getByRole('button', { name: 'Increase quantity for Soft Knit Sweater' }).click();
  await expect(page.getByTestId('subtotal')).toHaveText('$354.00');
  await page.getByRole('button', { name: 'Decrease quantity for Soft Knit Sweater' }).click();
  await expect(page.getByTestId('subtotal')).toHaveText('$236.00');
  await page.getByRole('button', { name: 'Remove Soft Knit Sweater from bag' }).click();
  await expect(page.getByRole('heading', { name: 'Room for something good.' })).toBeVisible();
  await page.reload();
  await expect(page.getByTestId('cart-count')).toHaveText('0');
});

test('different sizes remain separate and clear bag requires confirmation', async ({ page }) => {
  await addSweater(page, 'M');
  await addSweater(page, 'L');
  await page.goto('/cart');
  await expect(page.getByTestId('cart-line')).toHaveCount(2);
  await expect(page.getByTestId('cart-count')).toHaveText('2');
  await page.getByRole('button', { name: 'Clear bag', exact: true }).click();
  await page.getByRole('button', { name: 'Keep my pieces' }).click();
  await expect(page.getByTestId('cart-line')).toHaveCount(2);
  await page.getByRole('button', { name: 'Clear bag', exact: true }).click();
  await page.getByRole('button', { name: 'Yes, clear my bag' }).click();
  await expect(page.getByTestId('cart-count')).toHaveText('0');
});

test('cart caps quantities and sanitizes corrupt saved data', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.setItem('luxecart:cart:v1', JSON.stringify([
    { productId: 'soft-knit-sweater', size: 'M', color: 'Oat', quantity: 99 },
    { productId: 'unknown', size: 'M', color: 'Oat', quantity: 2 },
    { productId: 'city-leather-tote', size: 'wrong', color: 'Espresso / Sand', quantity: 1 },
    { productId: 'essential-cotton-tee', size: 'S', color: 'White', quantity: -3 },
  ])));
  await page.goto('/cart');
  await expect(page.getByTestId('cart-line')).toHaveCount(1);
  await expect(page.getByTestId('cart-count')).toHaveText('8');
  await expect(page.getByRole('button', { name: 'Increase quantity for Soft Knit Sweater' })).toBeDisabled();
  await page.evaluate(() => localStorage.setItem('luxecart:cart:v1', '{broken'));
  await page.reload();
  await expect(page.getByTestId('cart-count')).toHaveText('0');
});

test('sold-out product cannot be added and empty checkout redirects', async ({ page }) => {
  await page.goto('/product/everyday-leather-watch');
  await expect(page.getByRole('button', { name: 'Out of stock' })).toBeDisabled();
  await page.goto('/checkout');
  await expect(page).toHaveURL(/\/cart$/);
});

test('validated demo checkout, shipping totals, confirmation and privacy', async ({ page }) => {
  await addSweater(page);
  await page.goto('/cart');
  await expect(page.getByTestId('shipping')).toHaveText('$8.00');
  await expect(page.getByTestId('total')).toHaveText('$126.00');
  await page.getByRole('link', { name: 'Continue to checkout' }).click();
  await page.getByRole('button', { name: 'Place demo order' }).click();
  await expect(page.getByText('Enter a valid email address.')).toBeVisible();
  await expect(page.getByText('Select a delivery country.')).toBeVisible();
  await expect(page.getByText('Please acknowledge that this is a demonstration.')).toBeVisible();
  await page.getByRole('button', { name: 'Use sample details' }).click();
  await page.getByLabel(/Express delivery/).check();
  await expect(page.getByTestId('total')).toHaveText('$136.00');
  await page.getByLabel('I understand this is a demo. No real order will be fulfilled.').check();
  await expect(page.locator('input[type="password"], input[name*="card" i], input[name*="cvv" i]')).toHaveCount(0);
  await page.getByRole('button', { name: 'Place demo order' }).click();
  await expect(page).toHaveURL(/order-confirmation/);
  await expect(page.getByRole('heading', { name: 'A good choice, indeed.' })).toBeVisible();
  await expect(page.getByTestId('confirmation-total')).toHaveText('$136.00');
  await expect(page.getByTestId('cart-count')).toHaveText('0');
  const stored = await page.evaluate(() => JSON.stringify({ local: { ...localStorage }, session: { ...sessionStorage } }));
  expect(stored).not.toContain('alex@example.com');
  expect(stored).not.toContain('123 Studio Lane');
  expect(stored).not.toContain('Alex');
  await page.reload();
  await expect(page.getByTestId('confirmation-total')).toHaveText('$136.00');
  await page.goto('/cart');
  await expect(page.getByRole('heading', { name: 'Room for something good.' })).toBeVisible();
});

test('free shipping threshold is applied at exactly $150', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.setItem('luxecart:cart:v1', JSON.stringify([
    { productId: 'soft-knit-sweater', size: 'M', color: 'Oat', quantity: 1 },
    { productId: 'essential-cotton-tee', size: 'M', color: 'White', quantity: 1 },
  ])));
  await page.goto('/cart');
  await expect(page.getByTestId('subtotal')).toHaveText('$166.00');
  await expect(page.getByTestId('shipping')).toHaveText('Complimentary');
  await expect(page.getByTestId('total')).toHaveText('$166.00');
});

test('contact and newsletter validate and clearly simulate submission', async ({ page }) => {
  await page.goto('/contact');
  await page.getByRole('button', { name: 'Send demo message' }).click();
  await expect(page.getByText('Please enter your name.')).toBeVisible();
  await page.getByRole('button', { name: 'Use sample details' }).click();
  await page.getByRole('button', { name: 'Send demo message' }).click();
  await expect(page.getByRole('heading', { name: 'Looking good.' })).toBeVisible();
  await expect(page.getByText('No message was sent and your details were not saved.')).toBeVisible();
  await page.goto('/');
  await page.getByLabel('Email address', { exact: true }).fill('invalid');
  await page.getByRole('button', { name: 'Join the demo newsletter' }).click();
  await expect(page.getByText('Please enter a valid email address.')).toBeVisible();
  await page.getByLabel('Email address', { exact: true }).fill('reader@example.com');
  await page.getByRole('button', { name: 'Join the demo newsletter' }).click();
  await expect(page.getByText('You’re on the demo list.')).toBeVisible();
  expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain('reader@example.com');
});

test('mobile navigation and filter drawer are usable', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'Mobile-only controls');
  await page.goto('/');
  await page.getByRole('button', { name: 'Open navigation' }).click();
  await page.getByRole('navigation', { name: 'Mobile navigation' }).getByRole('link', { name: 'Bags', exact: true }).click();
  await expect(page).toHaveURL(/category=Bags/);
  await expect(page.getByTestId('product-card')).toHaveCount(4);
  await page.getByRole('button', { name: /Filters/ }).click();
  await page.getByRole('dialog').getByLabel('Under $100').click();
  await expect(page.getByRole('dialog').getByLabel('Under $100')).toBeChecked();
  await page.getByRole('button', { name: 'Show 1 piece' }).click();
  await expect(page.getByTestId('product-card')).toHaveCount(1);
  await expect(page.getByTestId('product-card')).toContainText('Woven Summer Bag');
});

test('size guide and product accordions work', async ({ page }) => {
  await page.goto('/product/soft-knit-sweater');
  await page.getByRole('button', { name: 'Size guide', exact: true }).click();
  await expect(page.getByRole('dialog')).toContainText('Chest (cm)');
  await page.keyboard.press('Escape');
  await page.getByText('Materials & care', { exact: true }).click();
  await expect(page.getByText(/70% cotton, 30% recycled wool/)).toBeVisible();
});

test('unknown routes show a useful 404 page', async ({ page }) => {
  await page.goto('/product/does-not-exist');
  await expect(page.getByRole('heading', { name: 'This piece of the story is missing.' })).toBeVisible();
  await page.getByRole('link', { name: 'Back to the collection' }).click();
  await expect(page).toHaveURL(/\/shop$/);
});

test('no horizontal overflow at common viewport widths', async ({ page, isMobile }) => {
  test.skip(isMobile, 'Desktop project checks all breakpoints');
  for (const width of [320, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    for (const route of ['/', '/shop', '/product/soft-knit-sweater', '/about', '/contact']) {
      await page.goto(route);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
      expect(overflow, `${route} at ${width}px`).toBe(false);
    }
  }
});

test('key pages pass automated accessibility checks @a11y', async ({ page }) => {
  test.setTimeout(90000);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  for (const route of ['/', '/shop', '/product/soft-knit-sweater', '/contact']) {
    await page.goto(route);
    const result = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(result.violations.map((v) => ({ id: v.id, impact: v.impact, nodes: v.nodes.map((n) => ({ target: n.target, summary: n.failureSummary })) })), route).toEqual([]);
  }
});

test('capture portfolio screenshots @capture', async ({ page, isMobile }, testInfo) => {
  test.setTimeout(120000);
  const device = isMobile ? 'mobile' : 'desktop';
  const capture = async (name: string, fullPage = true) => {
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(async () => { await Promise.all([...document.images].map((image) => image.decode().catch(() => undefined))); });
    await page.mouse.move(0, 0);
    await page.screenshot({ path: `screenshots/${name}-${device}.png`, fullPage, animations: 'disabled' });
  };
  await page.goto('/');
  await capture('home');
  await capture('home-viewport', false);
  await page.goto('/shop');
  await capture('shop');
  await page.goto('/product/soft-knit-sweater');
  await page.getByRole('button', { name: 'M', exact: true }).click();
  await capture('product');
  await page.evaluate(() => localStorage.setItem('luxecart:cart:v1', JSON.stringify([
    { productId: 'soft-knit-sweater', size: 'M', color: 'Oat', quantity: 1 },
    { productId: 'city-leather-tote', size: 'One size', color: 'Espresso / Sand', quantity: 1 },
  ])));
  await page.goto('/cart');
  await capture('cart');
  await page.getByRole('link', { name: 'Continue to checkout' }).click();
  await page.getByRole('button', { name: 'Use sample details' }).click();
  await capture('checkout');
  await page.getByLabel('I understand this is a demo. No real order will be fulfilled.').check();
  await page.getByRole('button', { name: 'Place demo order' }).click();
  await expect(page.getByTestId('confirmation-total')).toHaveText('$306.00');
  await capture('confirmation');
  await page.goto('/about');
  await capture('about');
  await page.goto('/contact');
  await capture('contact');
  expect(testInfo.project.name).toBeTruthy();
});
