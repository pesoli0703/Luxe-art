import { getProduct, products } from '../data/products';
import type { Product } from '../data/products';
import { assetUrl } from './assets';

export const CART_KEY = 'luxecart:cart:v1';
export const RECEIPT_KEY = 'luxecart:demo-receipt:v1';
export const MAX_QUANTITY = 10;
export type CartItem = { productId: string; size: string; color: string; quantity: number };
export type CartLine = CartItem & { key: string; product: Product; lineTotal: number };
export type ShippingMethod = 'standard' | 'express';
export const lineKey = (item: Pick<CartItem, 'productId' | 'size' | 'color'>) => JSON.stringify([item.productId, item.size, item.color]);
export const availableQuantity = (product: Product) => Math.min(product.stock, MAX_QUANTITY);

export function sanitizeCart(value: unknown): CartItem[] {
  if (!Array.isArray(value)) return [];
  const seen = new Map<string, CartItem>();
  for (const raw of value.slice(0, 200)) {
    if (!raw || typeof raw !== 'object') continue;
    const item = raw as Record<string, unknown>;
    const product = typeof item.productId === 'string' ? getProduct(item.productId) : undefined;
    if (!product || product.stock === 0 || typeof item.size !== 'string' || typeof item.color !== 'string') continue;
    if (!product.sizes.includes(item.size) || !product.colors.some((color) => color.name === item.color)) continue;
    if (typeof item.quantity !== 'number' || !Number.isInteger(item.quantity) || item.quantity < 1) continue;
    const clean: CartItem = { productId: product.id, size: item.size, color: item.color, quantity: Math.min(item.quantity, availableQuantity(product)) };
    const key = lineKey(clean);
    const existing = seen.get(key);
    if (existing) existing.quantity = Math.min(existing.quantity + clean.quantity, availableQuantity(product));
    else seen.set(key, clean);
  }
  return [...seen.values()];
}

export function readCart(): { items: CartItem[]; warning: string | null } {
  try {
    const raw = localStorage.getItem(CART_KEY);
    if (!raw) return { items: [], warning: null };
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return { items: [], warning: 'Your saved bag could not be read. A fresh bag is ready.' };
    return { items: sanitizeCart(parsed), warning: null };
  } catch {
    return { items: [], warning: 'Saved bag storage is unavailable. Your bag will work for this visit.' };
  }
}

export function getCartLines(items: CartItem[]): CartLine[] {
  return items.flatMap((item) => {
    const product = getProduct(item.productId);
    if (!product) return [];
    return [{ ...item, key: lineKey(item), product, lineTotal: product.price * item.quantity }];
  });
}

export function getTotals(items: CartItem[], method: ShippingMethod = 'standard') {
  const subtotal = getCartLines(items).reduce((sum, item) => sum + item.lineTotal, 0);
  const shipping = subtotal === 0 || (method === 'standard' && subtotal >= 15000) ? 0 : method === 'express' ? 1800 : 800;
  return { subtotal, shipping, tax: 0, total: subtotal + shipping, count: items.reduce((sum, item) => sum + item.quantity, 0) };
}

export type DemoReceipt = {
  id: string;
  createdAt: string;
  items: { name: string; image: string; size: string; color: string; quantity: number; unitPrice: number }[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  shippingMethod: ShippingMethod;
};

export function makeReceipt(items: CartItem[], method: ShippingMethod): DemoReceipt {
  const random = new Uint32Array(1);
  crypto.getRandomValues(random);
  return {
    id: `LC-${random[0].toString(36).toUpperCase().padStart(7, '0')}`,
    createdAt: new Date().toISOString(),
    items: getCartLines(items).map(({ product, quantity, size, color }) => ({ name: product.name, image: product.image, quantity, size, color, unitPrice: product.price })),
    ...getTotals(items, method), shippingMethod: method,
  };
}

export function readReceipt(): DemoReceipt | null {
  try { return parseReceipt(JSON.parse(sessionStorage.getItem(RECEIPT_KEY) || 'null')); }
  catch { return null; }
}

export function parseReceipt(value: unknown): DemoReceipt | null {
  try {
    if (!value || typeof value !== 'object') return null;
    const r = value as Record<string, unknown>;
    if (typeof r.id !== 'string' || typeof r.createdAt !== 'string' || Number.isNaN(Date.parse(r.createdAt))) return null;
    if (!['standard', 'express'].includes(String(r.shippingMethod))) return null;
    if (!['subtotal', 'shipping', 'tax', 'total'].every((key) => typeof r[key] === 'number' && Number.isSafeInteger(r[key]) && (r[key] as number) >= 0)) return null;
    if (!Array.isArray(r.items) || r.items.length === 0 || r.items.length > products.length * 20) return null;
    for (const item of r.items) {
      if (!item || typeof item !== 'object') return null;
      if (!['name', 'image', 'size', 'color'].every((key) => typeof item[key] === 'string')) return null;
      const imagePrefixes = ['/images/', assetUrl('images/')];
      if (!imagePrefixes.some((prefix) => String(item.image).startsWith(prefix)) || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > MAX_QUANTITY) return null;
      if (!Number.isSafeInteger(item.unitPrice) || item.unitPrice < 0) return null;
    }
    const receipt = value as DemoReceipt;
    const subtotal = receipt.items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
    if (subtotal !== receipt.subtotal || receipt.total !== receipt.subtotal + receipt.shipping + receipt.tax) return null;
    return receipt;
  } catch { return null; }
}
