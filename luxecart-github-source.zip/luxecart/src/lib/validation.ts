export type CheckoutValues = {
  firstName: string; lastName: string; email: string; address: string;
  apartment: string; city: string; postalCode: string; country: string;
};
export type FieldErrors = Partial<Record<keyof CheckoutValues, string>>;
export const emptyCheckout: CheckoutValues = { firstName: '', lastName: '', email: '', address: '', apartment: '', city: '', postalCode: '', country: '' };
export const demoCheckout: CheckoutValues = { firstName: 'Alex', lastName: 'Morgan', email: 'alex@example.com', address: '123 Studio Lane', apartment: 'Suite 4', city: 'New York', postalCode: '10001', country: 'US' };
export const countries = [{ value: 'US', label: 'United States' }, { value: 'CA', label: 'Canada' }, { value: 'GB', label: 'United Kingdom' }, { value: 'AU', label: 'Australia' }, { value: 'DE', label: 'Germany' }, { value: 'FR', label: 'France' }, { value: 'NG', label: 'Nigeria' }];

export function validateCheckout(values: CheckoutValues): FieldErrors {
  const errors: FieldErrors = {};
  const required: [keyof CheckoutValues, string][] = [['firstName', 'Enter your first name.'], ['lastName', 'Enter your last name.'], ['address', 'Enter a street address.'], ['city', 'Enter your city.']];
  for (const [key, message] of required) if (values[key].trim().length < 2) errors[key] = message;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) errors.email = 'Enter a valid email address.';
  if (values.address.trim().length > 200) errors.address = 'Keep the street address under 200 characters.';
  if (values.city.trim().length > 100) errors.city = 'Keep the city under 100 characters.';
  if (values.firstName.trim().length > 60) errors.firstName = 'Keep the first name under 60 characters.';
  if (values.lastName.trim().length > 60) errors.lastName = 'Keep the last name under 60 characters.';
  if (!/^[a-zA-Z0-9][a-zA-Z0-9 -]{1,11}$/.test(values.postalCode.trim())) errors.postalCode = 'Enter a valid postal or ZIP code.';
  if (!countries.some((country) => country.value === values.country)) errors.country = 'Select a delivery country.';
  return errors;
}

export type ContactValues = { name: string; email: string; subject: string; message: string };
export type ContactErrors = Partial<Record<keyof ContactValues, string>>;
export function validateContact(values: ContactValues): ContactErrors {
  const errors: ContactErrors = {};
  if (values.name.trim().length < 2) errors.name = 'Please enter your name.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) errors.email = 'Please enter a valid email address.';
  if (!values.subject) errors.subject = 'Please choose a topic.';
  if (values.message.trim().length < 10) errors.message = 'Please write at least 10 characters.';
  return errors;
}
