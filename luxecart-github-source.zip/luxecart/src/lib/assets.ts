/** Prefix public assets with Vite's base path so GitHub Pages project sites work. */
export function assetUrl(path: string): string {
  const clean = path.replace(/^\/+/, '');
  const base = import.meta.env.BASE_URL.endsWith('/') ? import.meta.env.BASE_URL : `${import.meta.env.BASE_URL}/`;
  return `${base}${clean}`;
}
