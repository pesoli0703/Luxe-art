import { ArrowUpRight, Plus } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { formatMoney, requiresSize } from '../data/products';
import type { Product } from '../data/products';
import { useCart } from '../context/CartContext';

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { addItem } = useCart();
  const navigate = useNavigate();
  const quickAdd = () => {
    if (requiresSize(product)) navigate(`/product/${product.id}`);
    else addItem(product, product.sizes[0], product.colors[0].name);
  };
  return <article className="product-card group" style={{ animationDelay: `${Math.min(index, 7) * 45}ms` }} data-testid="product-card">
    <div className="product-image-wrap">
      <Link to={`/product/${product.id}`} className="product-image-link" aria-label={`View ${product.name}, ${formatMoney(product.price)}`}>
        <img src={product.image} alt={product.alt} loading="lazy" width="600" height="750" className={`product-image image-${product.id}`} />
      </Link>
      {product.badge && <span className={`product-badge ${product.stock === 0 ? 'sold-out' : ''}`}>{product.badge}</span>}
      {product.stock > 0 && <button className="quick-add" onClick={quickAdd} aria-label={requiresSize(product) ? `Choose options for ${product.name}` : `Add ${product.name} to bag`}><span>{requiresSize(product) ? 'Choose options' : 'Add to bag'}</span><Plus size={17} /></button>}
      {product.stock === 0 && <span className="sold-out-overlay">Currently resting</span>}
    </div>
    <div className="product-info"><p className="product-category">{product.category}</p><div className="product-title-row"><h3><Link to={`/product/${product.id}`}>{product.name}</Link></h3><span>{formatMoney(product.price)}</span></div><div className="product-color-row"><div className="flex gap-1.5">{product.colors.map((color) => <span key={color.name} className="small-swatch" style={{ backgroundColor: color.hex }} title={color.name} />)}</div><span>{product.colors.length > 1 ? `${product.colors.length} colours` : product.colors[0].name}</span><ArrowUpRight size={15} className="product-arrow" /></div></div>
  </article>;
}
