import { useEffect } from 'react';
import { Check, X } from 'lucide-react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { Header } from './Header';
import { Footer, Newsletter } from './Footer';
import { useCart } from '../context/CartContext';

const pageTitles: Record<string, string> = { '/': 'Less, but better.', '/shop': 'The Collection', '/cart': 'Your Bag', '/checkout': 'Demo Checkout', '/order-confirmation': 'Demo Order Confirmed', '/about': 'Our Story', '/contact': 'Say Hello' };
export function Layout() {
  const { pathname } = useLocation();
  const { toast, dismissToast } = useCart();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    const page = pathname.startsWith('/product/') ? 'The Details' : pageTitles[pathname] ?? 'Page Not Found';
    document.title = `${page} — LUXECART`;
  }, [pathname]);
  const showNewsletter = ['/', '/shop', '/about'].includes(pathname) || pathname.startsWith('/product/');
  return <><a className="skip-link" href="#main-content">Skip to content</a><Header /><main id="main-content" tabIndex={-1}><Outlet /></main>{showNewsletter && <Newsletter />}<Footer />
    {toast && <div className="toast" role="status" aria-live="polite" key={toast.id}>{toast.image ? <img src={toast.image} alt="" width="42" height="50" /> : <span className="toast-check"><Check size={18} /></span>}<div><p>{toast.message}</p>{toast.cartLink && <Link to="/cart" onClick={dismissToast}>View your bag <span aria-hidden="true">→</span></Link>}</div><button aria-label="Dismiss notification" onClick={dismissToast}><X size={17} /></button></div>}
  </>;
}
