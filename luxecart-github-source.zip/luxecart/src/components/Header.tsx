import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { ArrowRight, Menu, Search, ShoppingBag, Sparkles } from 'lucide-react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { categories, formatMoney, products } from '../data/products';
import { useCart } from '../context/CartContext';
import { Modal } from './UI';

export function Header() {
  const { count } = useCart();
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => { setMenuOpen(false); setSearchOpen(false); }, [location.pathname, location.search]);
  const results = query.trim() ? products.filter((product) => `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(query.trim().toLowerCase())).slice(0, 4) : products.slice(0, 3);
  const submitSearch = (event: FormEvent) => { event.preventDefault(); navigate(`/shop?q=${encodeURIComponent(query.trim())}`); setSearchOpen(false); };
  const navClass = ({ isActive }: { isActive: boolean }) => `nav-link ${isActive ? 'active' : ''}`;
  return <>
    <div className="announcement"><div className="page-container announcement-inner"><span className="announcement-side">Thoughtfully selected. Effortlessly you.</span><Link to="/shop">Complimentary shipping on orders $150+ <ArrowRight size={13} /></Link><span className="announcement-demo"><span />CONCEPT STORE</span></div></div>
    <header className="site-header"><div className="page-container header-inner">
      <button className="icon-button mobile-menu-button" aria-label="Open navigation" onClick={() => setMenuOpen(true)}><Menu size={23} /></button>
      <Link to="/" className="wordmark" aria-label="LUXECART home">LUXECART<span>®</span></Link>
      <nav className="desktop-nav" aria-label="Main navigation"><NavLink to="/" end className={navClass}>Home</NavLink><NavLink to="/shop" className={({ isActive }) => `nav-link ${isActive || location.pathname.startsWith('/product/') ? 'active' : ''}`}>Shop <span className="nav-dot" /></NavLink><NavLink to="/about" className={navClass}>Our story</NavLink><NavLink to="/contact" className={navClass}>Contact</NavLink></nav>
      <div className="header-actions"><button className="icon-button" aria-label="Search products" onClick={() => { setQuery(''); setSearchOpen(true); }}><Search size={21} strokeWidth={1.6} /></button><Link to="/cart" className="bag-button" aria-label={`Shopping bag, ${count} ${count === 1 ? 'item' : 'items'}`}><ShoppingBag size={21} strokeWidth={1.6} /><span className="bag-label">Bag</span><span className="bag-count" data-testid="cart-count">{count}</span></Link></div>
    </div></header>
    {searchOpen && <Modal title="Find your next everyday." onClose={() => setSearchOpen(false)} wide>
      <form className="search-form" onSubmit={submitSearch}><Search size={22} /><label htmlFor="global-search" className="sr-only">Search products</label><input id="global-search" data-autofocus type="search" placeholder="Try “knit”, “leather” or “bags”…" value={query} onChange={(event) => setQuery(event.target.value)} maxLength={100} autoComplete="off" /><button type="submit" aria-label="Submit search"><ArrowRight size={22} /></button></form>
      <div className="search-results"><p className="eyebrow">{query.trim() ? `${results.length ? 'A few good finds' : 'No matches yet'}` : 'A good place to start'}</p>{results.map((product) => <Link key={product.id} to={`/product/${product.id}`} className="search-result" onClick={() => setSearchOpen(false)}><img src={product.image} alt="" width="58" height="68" /><span><strong>{product.name}</strong><small>{product.category}</small></span><span>{formatMoney(product.price)}</span><ArrowRight size={17} /></Link>)}{query.trim() && !results.length && <p className="text-sm text-muted py-5">Try a product name, material or category.</p>}<Link to={`/shop?q=${encodeURIComponent(query.trim())}`} className="text-link mt-5" onClick={() => setSearchOpen(false)}>Search the full collection<ArrowRight size={16} /></Link></div>
    </Modal>}
    {menuOpen && <Modal title="LUXECART" onClose={() => setMenuOpen(false)} drawer><nav className="mobile-nav" aria-label="Mobile navigation"><Link to="/" onClick={() => setMenuOpen(false)}>Home<ArrowRight size={22} /></Link><Link to="/shop" onClick={() => setMenuOpen(false)}>Shop all<ArrowRight size={22} /></Link><p className="eyebrow mt-8 mb-3">Find your category</p>{categories.map((category) => <Link key={category} className="mobile-category" to={`/shop?category=${category}`} onClick={() => setMenuOpen(false)}>{category}<ArrowRight size={17} /></Link>)}<Link to="/about" onClick={() => setMenuOpen(false)}>Our story<ArrowRight size={22} /></Link><Link to="/contact" onClick={() => setMenuOpen(false)}>Contact<ArrowRight size={22} /></Link></nav><div className="mobile-menu-note"><Sparkles size={22} /><p>Less, but better.<br /><span>A considered edit for your everyday.</span></p></div></Modal>}
  </>;
}
