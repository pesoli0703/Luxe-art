import { ShieldCheck, Truck } from 'lucide-react';
import { formatMoney } from '../data/products';
import { getCartLines, getTotals } from '../lib/cart';
import type { CartItem, ShippingMethod } from '../lib/cart';

export function OrderSummary({ items, method = 'standard', children }: { items: CartItem[]; method?: ShippingMethod; children?: React.ReactNode }) {
  const totals = getTotals(items, method);
  return <div className="order-summary-inner">
    <div className="summary-items">{items.map((item, index) => <SummaryLine key={`${item.productId}-${item.size}-${item.color}-${index}`} item={item} />)}</div>
    <dl className="totals-list"><div><dt>Subtotal <span className="text-muted">({totals.count} {totals.count === 1 ? 'item' : 'items'})</span></dt><dd data-testid="subtotal">{formatMoney(totals.subtotal)}</dd></div><div><dt>Shipping</dt><dd data-testid="shipping">{totals.shipping === 0 ? <span className="text-olive">Complimentary</span> : formatMoney(totals.shipping)}</dd></div><div><dt>Estimated tax</dt><dd>{formatMoney(totals.tax)}</dd></div></dl>
    <p className="tax-note">Demo prices in USD. No tax is collected.</p>
    <div className="grand-total"><span>Total</span><span data-testid="total">{formatMoney(totals.total)}</span></div>
    {children}
    <div className="summary-reassurance"><span><ShieldCheck size={16} />No payment details collected</span><span><Truck size={16} />{method === 'express' ? 'Express: 1–2 business days (demo)' : 'Standard: 3–5 business days (demo)'}</span></div>
  </div>;
}

function SummaryLine({ item }: { item: CartItem }) {
  const line = getCartLines([item])[0];
  if (!line) return null;
  return <div className="summary-item"><div className="summary-item-image"><img src={line.product.image} alt={line.product.alt} width="72" height="88" /><span>{item.quantity}</span></div><div className="min-w-0 flex-1"><h3>{line.product.name}</h3><p>{item.color}{item.size !== 'One size' ? ` / ${item.size}` : ''}</p></div><span className="summary-item-price">{formatMoney(line.lineTotal)}</span></div>;
}
