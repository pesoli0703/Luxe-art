import type { InputHTMLAttributes } from 'react';
export function InputField({ label, error, optional = false, id, ...props }: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; optional?: boolean; id: string }) {
  return <div className="form-field"><label htmlFor={id}>{label}{optional ? <span>(optional)</span> : <span className="required-mark">*</span>}</label><input id={id} className={error ? 'invalid' : ''} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} {...props} />{error && <p className="field-error" id={`${id}-error`}>{error}</p>}</div>;
}
