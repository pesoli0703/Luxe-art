import { useEffect, useId, useRef } from 'react';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { ArrowRight, ChevronRight, Minus, Plus, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPortal } from 'react-dom';

export function Button({ children, variant = 'primary', className = '', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'outline' | 'sand'; children: ReactNode }) {
  return <button className={`btn btn-${variant} ${className}`} {...props}>{children}</button>;
}

export function Eyebrow({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <p className={`eyebrow ${className}`}>{children}</p>;
}

export function SectionHeading({ eyebrow, title, link, linkText = 'View all pieces' }: { eyebrow: string; title: string; link?: string; linkText?: string }) {
  return <div className="section-heading"><div><Eyebrow>{eyebrow}</Eyebrow><h2>{title}</h2></div>{link && <Link to={link} className="text-link">{linkText}<ArrowRight size={17} /></Link>}</div>;
}

export function Breadcrumbs({ items }: { items: { label: string; to?: string }[] }) {
  return <nav aria-label="Breadcrumb" className="breadcrumbs"><Link to="/">Home</Link>{items.map((item, index) => <span key={`${item.label}-${index}`} className="inline-flex items-center gap-2"><ChevronRight size={12} />{item.to ? <Link to={item.to}>{item.label}</Link> : <span aria-current="page">{item.label}</span>}</span>)}</nav>;
}

export function QuantityControl({ value, onChange, max, label = 'Quantity', compact = false }: { value: number; onChange: (value: number) => void; max: number; label?: string; compact?: boolean }) {
  return <div className={`quantity-control ${compact ? 'compact' : ''}`}>
    <button type="button" aria-label={`Decrease ${label.toLowerCase()}`} disabled={value <= 1} onClick={() => onChange(value - 1)}><Minus size={14} /></button>
    <span aria-live="polite" aria-label={label}>{value}</span>
    <button type="button" aria-label={`Increase ${label.toLowerCase()}`} disabled={value >= max} onClick={() => onChange(value + 1)}><Plus size={14} /></button>
  </div>;
}

export function Modal({ title, children, onClose, wide = false, drawer = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean; drawer?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const titleId = useId();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const root = document.getElementById('root');
    root?.setAttribute('inert', '');
    const focusable = () => Array.from(ref.current?.querySelectorAll<HTMLElement>('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]') ?? []);
    const timer = window.setTimeout(() => { const target = ref.current?.querySelector<HTMLElement>('[data-autofocus]') ?? focusable()[0]; target?.focus(); }, 30);
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeRef.current();
      if (event.key !== 'Tab') return;
      const elements = focusable();
      const first = elements[0], last = elements[elements.length - 1];
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || !ref.current?.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !ref.current?.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', handleKey);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = previousOverflow;
      root?.removeAttribute('inert');
      if (previous?.isConnected) previous.focus();
    };
  }, []);
  return createPortal(<div className={`modal-backdrop ${drawer ? 'drawer-backdrop' : ''}`} onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId} className={`modal-panel ${wide ? 'modal-wide' : ''} ${drawer ? 'drawer-panel' : ''}`}>
      <div className="modal-header"><h2 id={titleId}>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={22} /></button></div>
      {children}
    </div>
  </div>, document.body);
}

export function Accordion({ title, children, defaultOpen = false }: { title: string; children: ReactNode; defaultOpen?: boolean }) {
  return <details className="accordion" open={defaultOpen || undefined}><summary>{title}<Plus size={17} className="accordion-plus" /><Minus size={17} className="accordion-minus" /></summary><div className="accordion-content">{children}</div></details>;
}

export function DemoNotice({ compact = false }: { compact?: boolean }) {
  return <div className={`demo-notice ${compact ? 'compact' : ''}`}><span className="demo-dot" /><p><strong>Demo store.</strong> {compact ? 'No real payments or deliveries.' : 'Explore freely. Checkout is a demonstration: no payment is collected, no products are shipped, and no card details are requested.'}</p></div>;
}
