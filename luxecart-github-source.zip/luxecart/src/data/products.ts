import { assetUrl } from '../lib/assets';

export const categories = ['Clothing', 'Shoes', 'Bags', 'Accessories'] as const;
export type Category = (typeof categories)[number];
export type ProductColor = { name: string; hex: string };
export type Product = {
  id: string;
  name: string;
  category: Category;
  price: number; // All money is stored in integer USD cents.
  image: string;
  alt: string;
  description: string;
  details: string[];
  material: string;
  colors: ProductColor[];
  sizes: string[];
  stock: number;
  badge?: string;
  position: number;
};

const apparel = ['XS', 'S', 'M', 'L', 'XL'];
const footwear = ['36', '37', '38', '39', '40', '41'];
const oneSize = ['One size'];
const image = (name: string) => assetUrl(`images/${name}.jpg`);

export const products: Product[] = [
  {
    id: 'soft-knit-sweater', name: 'Soft Knit Sweater', category: 'Clothing', price: 11800,
    image: image('clothing-sweater'), alt: 'Close-up of an ivory chunky-knit sweater with soft textured sleeves',
    description: 'The layer you will reach for, again and again. A beautifully tactile knit with a relaxed silhouette, made for slow mornings and everything that follows.',
    details: ['Relaxed, easy-to-layer fit', 'Soft ribbed texture', 'Designed for everyday wear', 'The model photograph shows the Oat colourway'],
    material: 'Illustrative composition: 70% cotton, 30% recycled wool. Gentle cold wash; dry flat.',
    colors: [{ name: 'Oat', hex: '#d8cdbb' }, { name: 'Charcoal', hex: '#44443f' }], sizes: apparel, stock: 8, badge: 'Bestseller', position: 1,
  },
  {
    id: 'city-leather-tote', name: 'City Leather Tote', category: 'Bags', price: 18800,
    image: image('bag-shoulder'), alt: 'Structured dark-brown leather tote with contrasting sand handles and shoulder strap',
    description: 'Room for your day, beautifully organised. A structured everyday tote with contrasting handles and an adjustable strap that moves easily from shoulder to crossbody.',
    details: ['Interior slip pocket', 'Adjustable, detachable shoulder strap', 'Illustrative dimensions: 34 × 28 × 12 cm', 'Fits a 13-inch laptop'],
    material: 'Illustrative composition: textured leather with soft cotton-twill lining. Wipe with a damp cloth.',
    colors: [{ name: 'Espresso / Sand', hex: '#594034' }], sizes: oneSize, stock: 6, badge: 'The everyday icon', position: 2,
  },
  {
    id: 'court-leather-sneaker', name: 'Court Leather Sneaker', category: 'Shoes', price: 12800,
    image: image('shoes-sneaker'), alt: 'Clean white low-top leather court sneakers photographed against a dark background',
    description: 'A fresh perspective on an everyday classic. Clean lines, a cushioned footbed and a versatile low-top profile make these your new wear-with-everything pair.',
    details: ['Cushioned, removable insole', 'Durable rubber cupsole', 'True-to-size European fit', 'Reference photography; not a LUXECART-manufactured product'],
    material: 'Illustrative composition: leather upper, textile lining and rubber sole. Spot clean only.',
    colors: [{ name: 'White', hex: '#f4f3ee' }], sizes: footwear, stock: 10, badge: 'New', position: 3,
  },
  {
    id: 'classic-acetate-sunglasses', name: 'Classic Acetate Sunglasses', category: 'Accessories', price: 7800,
    image: image('acc-sunglasses'), alt: 'Black wayfarer-style sunglasses with dark lenses on a white surface',
    description: 'A little shade, a lot of character. Timeless black frames with a flattering silhouette, finished with dark lenses for a clean, understated look.',
    details: ['Classic unisex silhouette', 'Dark tinted lenses', 'Protective pouch included in the fictional product specification', 'Reference photography; no affiliation with the photographed brand'],
    material: 'Illustrative composition: polished acetate frame. Store in its pouch; clean with a microfibre cloth.',
    colors: [{ name: 'Black', hex: '#242520' }], sizes: oneSize, stock: 12, badge: 'Editor’s pick', position: 4,
  },
  {
    id: 'essential-cotton-tee', name: 'Essential Cotton Tee', category: 'Clothing', price: 4800,
    image: image('clothing-tee'), alt: 'A plain white crew-neck cotton T-shirt worn in natural daylight',
    description: 'The foundation of a well-dressed everyday. A clean crew neck, an easy fit and a satisfyingly soft hand feel. Simple, considered, endlessly wearable.',
    details: ['Regular fit', 'Classic crew neckline', 'Straight hem', 'The model photograph shows the White colourway'],
    material: 'Illustrative composition: 100% organic cotton. Machine wash cold with similar colours.',
    colors: [{ name: 'White', hex: '#f8f8f4' }, { name: 'Ink', hex: '#292a27' }], sizes: apparel, stock: 15, position: 5,
  },
  {
    id: 'relaxed-city-blazer', name: 'Relaxed City Blazer', category: 'Clothing', price: 16800,
    image: image('clothing-blazer'), alt: 'Woman wearing a relaxed sand-coloured blazer with matching wide-leg trousers',
    description: 'Tailoring, without the rules. A softly structured blazer with generous proportions. Throw it over a tee, pair it with denim, or make it a matching set.',
    details: ['Relaxed, slightly oversized fit', 'Notched lapels and flap pockets', 'Double-button front', 'Trousers shown are not included'],
    material: 'Illustrative composition: 65% recycled polyester, 35% viscose. Dry clean recommended.',
    colors: [{ name: 'Sand', hex: '#cdbdaf' }], sizes: apparel, stock: 5, badge: 'New', position: 6,
  },
  {
    id: 'everyday-oxford-shirt', name: 'Everyday Oxford Shirt', category: 'Clothing', price: 8800,
    image: image('clothing-shirt'), alt: 'Crisp white long-sleeved shirt worn with a dark patterned tie',
    description: 'A crisp classic with an easy attitude. Our concept Oxford brings a refined collar and a comfortable fit to the everyday rotation. Dress it up, roll the sleeves, make it yours.',
    details: ['Regular fit with long sleeves', 'Button cuffs', 'Curved hem', 'Styling tie is not included'],
    material: 'Illustrative composition: 100% cotton Oxford weave. Machine wash cold; warm iron.',
    colors: [{ name: 'White', hex: '#f6f6f2' }], sizes: apparel, stock: 9, position: 7,
  },
  {
    id: 'sculpted-leather-mule', name: 'Sculpted Leather Mule', category: 'Shoes', price: 14800,
    image: image('shoes-mule'), alt: 'Black leather mules with woven straps and sculptural low heels on a warm stone floor',
    description: 'A modern line from every angle. Woven straps meet a gently sculpted heel in this slip-on pair that brings a little intention to everyday dressing.',
    details: ['Open square toe', 'Illustrative heel height: 5 cm', 'Slip-on design', 'For between sizes, choose the larger size'],
    material: 'Illustrative composition: leather upper and lining, leather-wrapped heel. Specialist leather care recommended.',
    colors: [{ name: 'Black', hex: '#22231f' }], sizes: footwear, stock: 7, badge: 'New', position: 8,
  },
  {
    id: 'heritage-chelsea-boot', name: 'Heritage Chelsea Boot', category: 'Shoes', price: 19800,
    image: image('shoes-boot'), alt: 'Worn tan leather Chelsea boots photographed on a textured stone path',
    description: 'A dependable companion for the long way home. A rounded toe, sturdy sole and rich leather finish give this everyday boot its quietly confident character.',
    details: ['Pull-on ankle boot silhouette', 'Grippy, durable outsole', 'Rounded toe', 'Photographed in a naturally worn finish'],
    material: 'Illustrative composition: leather upper, textile lining, rubber outsole. Brush clean and condition periodically.',
    colors: [{ name: 'Tan', hex: '#97734f' }], sizes: footwear, stock: 6, position: 9,
  },
  {
    id: 'classic-penny-loafer', name: 'Classic Penny Loafer', category: 'Shoes', price: 15800,
    image: image('shoes-loafer'), alt: 'Polished dark-brown leather loafers on a warm reflective surface',
    description: 'A borrowed-from-the-classics silhouette, made for now. A polished finish and an easy slip-on shape bring just the right amount of structure to your day.',
    details: ['Classic penny-style strap', 'Low stacked heel', 'Cushioned footbed', 'Pair with tailored trousers or relaxed denim'],
    material: 'Illustrative composition: leather upper with leather lining and a stacked heel. Polish with a neutral leather cream.',
    colors: [{ name: 'Dark brown', hex: '#4a342b' }], sizes: footwear, stock: 8, position: 10,
  },
  {
    id: 'structured-top-handle', name: 'Structured Top Handle', category: 'Bags', price: 16800,
    image: image('bag-tote'), alt: 'Bright terracotta structured handbag with a curved top handle and silver-tone clasp',
    description: 'A small statement in a beautiful colour. Crisp edges, a curved handle and a polished clasp make this compact companion the finishing touch your everyday outfit was looking for.',
    details: ['Structured silhouette', 'Top handle and detachable strap', 'Secure clasp closure', 'Illustrative dimensions: 25 × 20 × 10 cm'],
    material: 'Illustrative composition: grained leather with a soft textile lining. Store away from direct sunlight.',
    colors: [{ name: 'Terracotta', hex: '#bb4c34' }], sizes: oneSize, stock: 4, badge: 'Small batch', position: 11,
  },
  {
    id: 'city-day-backpack', name: 'City Day Backpack', category: 'Bags', price: 13800,
    image: image('bag-backpack'), alt: 'Minimal navy-blue backpack with a front zip pocket against a pale wall',
    description: 'Hands free, head clear. A streamlined backpack with space for the things that matter, designed to move from your morning commute to an unplanned weekend away.',
    details: ['Zip-top main compartment', 'Front quick-access pocket', 'Adjustable shoulder straps', 'Illustrative capacity: 16 litres'],
    material: 'Illustrative composition: durable woven canvas with reinforced stress points. Spot clean with mild soap.',
    colors: [{ name: 'Navy', hex: '#2c3544' }], sizes: oneSize, stock: 8, position: 12,
  },
  {
    id: 'woven-summer-bag', name: 'Woven Summer Bag', category: 'Bags', price: 9800,
    image: image('bag-clutch'), alt: 'Orange-tan woven basket bag with a structured leather top and handle',
    description: 'A little sunshine, carried with you. Natural-looking woven texture meets a warm leather finish in a cheerful bag for market mornings, long lunches and holidays close to home.',
    details: ['Structured woven body', 'Leather top handle', 'Detachable shoulder strap', 'Illustrative dimensions: 24 × 22 × 12 cm'],
    material: 'Illustrative composition: woven raffia with leather trim. Keep dry and store stuffed to retain its shape.',
    colors: [{ name: 'Natural / Tan', hex: '#c48a53' }], sizes: oneSize, stock: 5, position: 13,
  },
  {
    id: 'everyday-leather-watch', name: 'Everyday Leather Watch', category: 'Accessories', price: 15800,
    image: image('acc-watch'), alt: 'Round silver-tone watch with a light dial and brown leather strap',
    description: 'Time, thoughtfully kept. A classic round dial and warm leather strap make this an easy companion to everything already in your wardrobe. Currently resting in our concept edit.',
    details: ['Round analogue dial', 'Adjustable leather strap', 'Illustrative case diameter: 38 mm', 'Out of stock in this demonstration catalog'],
    material: 'Illustrative composition: stainless-steel case and leather strap. Avoid immersion and wipe with a soft cloth.',
    colors: [{ name: 'Silver / Brown', hex: '#8b6045' }], sizes: oneSize, stock: 0, position: 14,
  },
  {
    id: 'layered-pendant-necklace', name: 'Layered Pendant Necklace', category: 'Accessories', price: 6800,
    image: image('acc-jewelry'), alt: 'Fine layered gold-tone necklaces with small pendants worn against a white shirt',
    description: 'The smallest things make the difference. A delicate layered chain with a quiet glint of gold, designed to feel like it has always been part of your everyday.',
    details: ['Fine layered-chain look', 'Adjustable fastening', 'Lightweight feel', 'Keep away from perfume and moisture'],
    material: 'Illustrative composition: gold-tone plated brass. Store separately in a soft pouch.',
    colors: [{ name: 'Gold', hex: '#c5a364' }], sizes: oneSize, stock: 10, badge: 'Bestseller', position: 15,
  },
  {
    id: 'petite-pendant-necklace', name: 'Petite Pendant Necklace', category: 'Accessories', price: 5800,
    image: image('acc-bracelet'), alt: 'A single fine gold-tone chain with a small circular pendant worn with an open white shirt',
    description: 'One fine chain. One perfect little detail. A petite pendant that sits beautifully on its own or layers with the pieces you already love.',
    details: ['Single fine chain', 'Small circular pendant', 'Adjustable length', 'Nickel-free finish in the fictional product specification'],
    material: 'Illustrative composition: gold-tone plated sterling silver. Clean gently with a dry, soft cloth.',
    colors: [{ name: 'Gold', hex: '#c5a364' }], sizes: oneSize, stock: 12, position: 16,
  },
];

export const categoryImages: Record<Category, { image: string; alt: string; caption: string }> = {
  Clothing: { image: image('clothing-blazer'), alt: 'Relaxed neutral tailoring', caption: 'Effortless by nature' },
  Shoes: { image: image('shoes-mule'), alt: 'Sculptural black leather mules', caption: 'A step in your own direction' },
  Bags: { image: image('bag-shoulder'), alt: 'Brown leather everyday tote', caption: 'Carry a little possibility' },
  Accessories: { image: image('acc-sunglasses'), alt: 'Classic black sunglasses', caption: 'The finishing touches' },
};

export const getProduct = (id: string) => products.find((product) => product.id === id);
export const requiresSize = (product: Product) => product.sizes.length > 1;
export const formatMoney = (cents: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
