import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { ArrowLeft, ArrowRight, Check, LockKeyhole, Sparkles } from 'lucide-react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { getTotals, makeReceipt, RECEIPT_KEY } from '../lib/cart';
import { formatMoney } from '../data/products';
import type { ShippingMethod } from '../lib/cart';
import { countries, demoCheckout, emptyCheckout, validateCheckout } from '../lib/validation';
import type { CheckoutValues } from '../lib/validation';
import { Breadcrumbs, Button, DemoNotice, Eyebrow } from '../components/UI';
import { InputField } from '../components/FormField';
import { OrderSummary } from '../components/OrderSummary';

export function Checkout() {
  const { items, clearCart } = useCart();
  const navigate = useNavigate();
  const [values, setValues] = useState<CheckoutValues>(emptyCheckout);
  const [touched, setTouched] = useState<Partial<Record<keyof CheckoutValues, boolean>>>({});
  const [attempted, setAttempted] = useState(false);
  const [method, setMethod] = useState<ShippingMethod>('standard');
  const [accepted, setAccepted] = useState(false);
  const [consentError, setConsentError] = useState(false);
  const submitted = useRef(false);
  const errors = validateCheckout(values);
  const errorFor = (key: keyof CheckoutValues) => touched[key] || attempted ? errors[key] : undefined;
  const change = (key: keyof CheckoutValues, value: string) => setValues((previous) => ({ ...previous, [key]: value }));
  const blur = (key: keyof CheckoutValues) => setTouched((previous) => ({ ...previous, [key]: true }));
  const field = (key: keyof CheckoutValues, label: string, placeholder: string, autoComplete: string, type = 'text') => <InputField id={`checkout-${key}`} name={key} label={label} placeholder={placeholder} autoComplete={autoComplete} type={type} value={values[key]} onChange={(event) => change(key, event.target.value)} onBlur={() => blur(key)} error={errorFor(key)} optional={key === 'apartment'} required={key !== 'apartment'} maxLength={key === 'email' ? 254 : key === 'address' ? 200 : 100} />;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (submitted.current) return;
    setAttempted(true); setConsentError(!accepted);
    const firstError = Object.keys(errors)[0];
    if (firstError || !accepted) {
      requestAnimationFrame(() => document.getElementById(firstError ? `checkout-${firstError}` : 'demo-consent')?.focus());
      return;
    }
    submitted.current = true;
    const receipt = makeReceipt(items, method);
    try { sessionStorage.setItem(RECEIPT_KEY, JSON.stringify(receipt)); } catch { /* Navigation state still supports confirmation when storage is unavailable. */ }
    // Contact and delivery values are intentionally never persisted or transmitted.
    setValues(emptyCheckout);
    clearCart();
    navigate('/order-confirmation', { state: { receipt }, replace: true });
  };
  if (!items.length && !submitted.current) return <Navigate to="/cart" replace />;
  return <div className="page-container checkout-page"><Breadcrumbs items={[{ label: 'Your bag', to: '/cart' }, { label: 'Demo checkout' }]} /><div className="checkout-heading"><div><Eyebrow>ONE LAST LITTLE STEP</Eyebrow><h1>Make it yours.</h1></div><div className="checkout-secure"><LockKeyhole size={17} />No payment. No pressure.</div></div><DemoNotice /><div className="checkout-layout"><form className="checkout-form" onSubmit={submit} noValidate><div className="form-section-heading"><h2><span>01</span>Contact details</h2><button type="button" className="sample-details-button" onClick={() => { setValues(demoCheckout); setTouched({}); setAttempted(false); }}><Sparkles size={14} />Use sample details</button></div><p className="form-section-note">Use fictional details to try the experience. Nothing is sent or saved.</p><div className="form-row">{field('email', 'Email address', 'alex@example.com', 'email', 'email')}</div><div className="form-section-heading section-divider"><h2><span>02</span>Delivery address</h2></div><div className="form-row two-col">{field('firstName', 'First name', 'Alex', 'given-name')}{field('lastName', 'Last name', 'Morgan', 'family-name')}</div><div className="form-row">{field('address', 'Street address', '123 Studio Lane', 'address-line1')}</div><div className="form-row">{field('apartment', 'Apartment, suite, etc.', 'Suite 4', 'address-line2')}</div><div className="form-row two-col">{field('city', 'City', 'New York', 'address-level2')}{field('postalCode', 'Postal / ZIP code', '10001', 'postal-code')}</div><div className="form-field"><label htmlFor="checkout-country">Country<span className="required-mark">*</span></label><select id="checkout-country" name="country" autoComplete="country" value={values.country} onChange={(event) => change('country', event.target.value)} onBlur={() => blur('country')} required aria-invalid={!!errorFor('country')} aria-describedby={errorFor('country') ? 'checkout-country-error' : undefined} className={errorFor('country') ? 'invalid' : ''}><option value="">Select your country</option>{countries.map((country) => <option key={country.value} value={country.value}>{country.label}</option>)}</select>{errorFor('country') && <p id="checkout-country-error" className="field-error">{errorFor('country')}</p>}</div><div className="form-section-heading section-divider"><h2><span>03</span>Delivery method</h2></div><fieldset className="shipping-methods"><legend className="sr-only">Choose a demo delivery method</legend><label className={`shipping-method ${method === 'standard' ? 'selected' : ''}`}><input type="radio" name="shipping" value="standard" checked={method === 'standard'} onChange={() => setMethod('standard')} /><span><strong>Standard delivery</strong><small>3–5 business days · illustrative</small></span><span>{getTotals(items, 'standard').shipping === 0 ? 'Complimentary' : formatMoney(800)}</span></label><label className={`shipping-method ${method === 'express' ? 'selected' : ''}`}><input type="radio" name="shipping" value="express" checked={method === 'express'} onChange={() => setMethod('express')} /><span><strong>Express delivery</strong><small>1–2 business days · illustrative</small></span><span>$18.00</span></label></fieldset><div className="payment-demo-panel"><LockKeyhole size={21} strokeWidth={1.5} /><div><h3>Payment? Not in this demo.</h3><p>No card fields, no payment provider, no charge. Just a complete checkout demonstration.</p></div><Check size={19} /></div><label className="consent-label"><input id="demo-consent" type="checkbox" checked={accepted} onChange={(event) => { setAccepted(event.target.checked); setConsentError(false); }} aria-invalid={consentError} aria-describedby={consentError ? 'consent-error' : undefined} /><span>I understand this is a demo. No real order will be fulfilled.</span></label>{consentError && <p id="consent-error" className="field-error" role="alert">Please acknowledge that this is a demonstration.</p>}{attempted && Object.keys(errors).length > 0 && <p className="form-error-summary" role="alert">A few details need your attention. Check the highlighted fields above.</p>}<Button type="submit" className="w-full place-order-button">Place demo order<ArrowRight size={18} /></Button><p className="checkout-no-charge"><LockKeyhole size={13} />You will not be charged. No products will be shipped.</p><Link to="/cart" className="text-link mt-7"><ArrowLeft size={15} />Back to your bag</Link></form><aside className="checkout-summary"><h2>Your considered edit.</h2><OrderSummary items={items} method={method} /></aside></div></div>;

}
