import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Eyebrow } from '../components/UI';
export function NotFound() {
  return <div className="page-container empty-state not-found"><Eyebrow>404 / A LITTLE OFF TRACK</Eyebrow><h1>This piece of the story<br /><em>is missing.</em></h1><p>The page you’re looking for isn’t here. There are still plenty of good things to discover.</p><Link to="/shop" className="btn btn-primary">Back to the collection<ArrowRight size={17} /></Link></div>;
}
