import { useMemo, useState } from 'react';
import { ArrowRight, Search, SlidersHorizontal, X } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { categories, products } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { Breadcrumbs, Button, Eyebrow, Modal } from '../components/UI';

const sortOptions = [{ value: 'featured', label: 'Featured' }, { value: 'newest', label: 'Newest arrivals' }, { value: 'price-asc', label: 'Price: low to high' }, { value: 'price-desc', label: 'Price: high to low' }, { value: 'name', label: 'Name: A–Z' }];
const priceOptions = [{ value: 'all', label: 'All prices' }, { value: 'under-100', label: 'Under $100' }, { value: '100-200', label: '$100 – $200' }, { value: 'over-200', label: '$200 and above' }];

export function Shop() {
  const [params, setParams] = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);
  const query = params.get('q') ?? '';
  const rawCategory = params.get('category') ?? 'All';
  const category = categories.includes(rawCategory as typeof categories[number]) ? rawCategory : 'All';
  const sort = sortOptions.some((option) => option.value === params.get('sort')) ? params.get('sort')! : 'featured';
  const price = priceOptions.some((option) => option.value === params.get('price')) ? params.get('price')! : 'all';
  const inStock = params.get('available') === '1';
  const update = (key: string, value: string) => setParams((previous) => { const next = new URLSearchParams(previous); if (!value || value === 'all' || value === 'All' || value === 'featured') next.delete(key); else next.set(key, value); return next; }, { replace: true });
  const clear = () => setParams({}, { replace: true });
  const filtered = useMemo(() => {
    const terms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const result = products.filter((product) => {
      const text = `${product.name} ${product.category} ${product.description} ${product.material} ${product.colors.map((color) => color.name).join(' ')}`.toLowerCase();
      return terms.every((term) => text.includes(term)) && (category === 'All' || product.category === category) && (!inStock || product.stock > 0)
        && (price === 'all' || (price === 'under-100' && product.price < 10000) || (price === '100-200' && product.price >= 10000 && product.price < 20000) || (price === 'over-200' && product.price >= 20000));
    });
    return result.sort((a, b) => sort === 'price-asc' ? a.price - b.price : sort === 'price-desc' ? b.price - a.price : sort === 'name' ? a.name.localeCompare(b.name) : sort === 'newest' ? b.position - a.position : a.position - b.position);
  }, [query, category, sort, price, inStock]);
  const activeFilters = [category !== 'All' && { key: 'category', label: category }, query.trim() && { key: 'q', label: `“${query.trim()}”` }, price !== 'all' && { key: 'price', label: priceOptions.find((option) => option.value === price)?.label }, inStock && { key: 'available', label: 'In stock' }].filter(Boolean) as { key: string; label: string }[];
  const renderFilters = (scope: string) => <div className="filter-panel"><fieldset><legend>Category</legend>{['All', ...categories].map((item) => <label className="filter-option" key={item}><input type="radio" name={`category-${scope}`} checked={category === item} onChange={() => update('category', item)} /><span>{item === 'All' ? 'All pieces' : item}</span><small>{item === 'All' ? products.length : products.filter((product) => product.category === item).length}</small></label>)}</fieldset><fieldset><legend>Price range</legend>{priceOptions.map((option) => <label className="filter-option" key={option.value}><input type="radio" name={`price-${scope}`} checked={price === option.value} onChange={() => update('price', option.value)} /><span>{option.label}</span></label>)}</fieldset><fieldset><legend>Availability</legend><label className="filter-option"><input type="checkbox" checked={inStock} onChange={(event) => update('available', event.target.checked ? '1' : '')} /><span>In stock only</span></label></fieldset><button className="text-link filter-reset" onClick={clear}>Reset all filters<X size={14} /></button></div>;
  return <div className="page-container shop-page"><Breadcrumbs items={[{ label: 'The collection' }]} /><div className="shop-heading"><div><Eyebrow>GOOD PIECES. GREAT POSSIBILITIES.</Eyebrow><h1>{category === 'All' ? 'The everyday edit.' : `${category}, considered.`}</h1><p>A little of what you need. A lot of what you love.</p></div><span className="collection-count">16 pieces<br /><span>4 curated categories</span></span></div>
    <div className="shop-toolbar"><div className="shop-search"><Search size={19} /><label htmlFor="shop-search" className="sr-only">Search the collection</label><input id="shop-search" type="search" placeholder="Search the collection…" value={query} onChange={(event) => update('q', event.target.value)} maxLength={100} />{query && <button aria-label="Clear search" onClick={() => update('q', '')}><X size={16} /></button>}</div><div className="shop-toolbar-right"><button className="mobile-filter-button" onClick={() => setFiltersOpen(true)}><SlidersHorizontal size={17} />Filters{activeFilters.length > 0 && <span>{activeFilters.length}</span>}</button><div className="sort-control"><label htmlFor="product-sort">Sort by</label><select id="product-sort" aria-label="Sort products" value={sort} onChange={(event) => update('sort', event.target.value)}>{sortOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></div></div></div>
    <div className="shop-layout"><aside className="shop-sidebar" aria-label="Product filters"><p className="eyebrow mb-7">REFINE YOUR EDIT</p>{renderFilters('desktop')}<div className="sidebar-note"><span>Less, but better.</span><p>Every piece has a place.<br />Find the ones that feel like you.</p></div></aside><div className="shop-results"><div className="results-meta"><p aria-live="polite" data-testid="results-count">{filtered.length} {filtered.length === 1 ? 'piece' : 'pieces'}{category !== 'All' ? ` in ${category}` : ' to make your own'}</p><span>Thoughtfully selected, always.</span></div>{activeFilters.length > 0 && <div className="active-filters">{activeFilters.map((filter) => <button key={filter.key} onClick={() => update(filter.key, '')} aria-label={`Remove ${filter.label} filter`}>{filter.label}<X size={12} /></button>)}<button className="clear-filters" onClick={clear}>Clear all</button></div>}{filtered.length ? <div className="product-grid shop-product-grid">{filtered.map((product, index) => <ProductCard key={product.id} product={product} index={index} />)}</div> : <div className="empty-state"><Search size={36} strokeWidth={1} /><h2>No pieces found. Yet.</h2><p>Try a different search or give your filters a little more room.</p><Button onClick={clear}>Explore all pieces<ArrowRight size={17} /></Button></div>}</div></div>
    {filtersOpen && <Modal title="Refine your edit" onClose={() => setFiltersOpen(false)} drawer>{renderFilters('mobile')}<Button className="w-full mt-8" onClick={() => setFiltersOpen(false)}>Show {filtered.length} {filtered.length === 1 ? 'piece' : 'pieces'}<ArrowRight size={17} /></Button></Modal>}
  </div>;
}
