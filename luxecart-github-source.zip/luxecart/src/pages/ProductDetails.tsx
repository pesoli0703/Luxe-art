import { useEffect, useState } from 'react';
import { ArrowRight, Check, Expand, RefreshCcw, ShieldCheck, Truck } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { formatMoney, getProduct, products, requiresSize } from '../data/products';
import { availableQuantity } from '../lib/cart';
import { useCart } from '../context/CartContext';
import { Accordion, Breadcrumbs, Button, Eyebrow, Modal, QuantityControl, SectionHeading } from '../components/UI';
import { ProductCard } from '../components/ProductCard';
import { NotFound } from './NotFound';

export function ProductDetails() {
  const { id } = useParams();
  const product = getProduct(id ?? '');
  const { addItem } = useCart();
  const [size, setSize] = useState('');
  const [color, setColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState('');
  const [added, setAdded] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [imageOpen, setImageOpen] = useState(false);
  useEffect(() => { setSize(product && !requiresSize(product) ? product.sizes[0] : ''); setColor(product?.colors[0].name ?? ''); setQuantity(1); setError(''); setAdded(false); }, [product]);
  useEffect(() => { if (!added) return; const timer = window.setTimeout(() => setAdded(false), 2200); return () => window.clearTimeout(timer); }, [added]);
  if (!product) return <NotFound />;
  const max = availableQuantity(product);
  const related = [...products].filter((item) => item.id !== product.id).sort((a, b) => Number(b.category === product.category) - Number(a.category === product.category)).slice(0, 4);
  const add = () => {
    if (!size) { setError('Choose your size to make it yours.'); document.getElementById('size-options')?.focus(); return; }
    if (addItem(product, size, color, quantity)) { setAdded(true); setError(''); }
  };
  return <div className="page-container product-page"><Breadcrumbs items={[{ label: 'Shop', to: '/shop' }, { label: product.category, to: `/shop?category=${product.category}` }, { label: product.name }]} /><div className="product-detail-layout"><div className="detail-gallery"><div className="detail-image-wrap"><img src={product.image} alt={product.alt} width="800" height="1000" fetchPriority="high" />{product.badge && <span className="product-badge">{product.badge}</span>}<button className="image-expand" onClick={() => setImageOpen(true)} aria-label="Expand product photograph"><Expand size={19} /></button><span className="image-reference">THE CONSIDERED EDIT / {String(product.position).padStart(2, '0')}</span></div><p className="image-caption">A closer look at a piece worth knowing.<span>Reference photography</span></p></div><div className="product-detail-copy"><Link to={`/shop?category=${product.category}`} className="eyebrow detail-category">{product.category}<ArrowRight size={13} /></Link><h1>{product.name}</h1><p className="detail-price">{formatMoney(product.price)}<span>USD · demo price</span></p><p className="detail-description">{product.description}</p><div className="detail-stock"><span className={max ? 'stock-dot' : 'stock-dot out'} />{max ? max <= 5 ? `Just ${max} left in this demo edit` : 'In stock in our demo edit' : 'Currently out of stock'}</div>
      <div className="variant-section"><div className="variant-label"><span>Colour</span><strong>{color}</strong></div><div className="color-options">{product.colors.map((option) => <button key={option.name} className={`color-option ${color === option.name ? 'selected' : ''}`} onClick={() => { setColor(option.name); setAdded(false); }} aria-label={`Colour: ${option.name}`} aria-pressed={color === option.name}><span style={{ backgroundColor: option.hex }} />{color === option.name && <Check size={14} style={{ color: ['White', 'Oat', 'Sand'].includes(option.name) ? '#242520' : '#fff' }} />}</button>)}</div>{product.colors.length > 1 && <p className="variant-note">Photography shows {product.colors[0].name}. Other colours are demo options.</p>}</div>
      <div className="variant-section"><div className="variant-label"><span>{requiresSize(product) ? 'Size' : 'Fit'}</span>{requiresSize(product) && <button onClick={() => setGuideOpen(true)} className="size-guide-button">Size guide</button>}</div><div id="size-options" tabIndex={-1} className={`size-options ${error ? 'has-error' : ''}`} role="group" aria-label="Choose a size" aria-describedby={error ? 'size-error' : undefined}>{product.sizes.map((option) => <button key={option} className={`size-option ${size === option ? 'selected' : ''}`} onClick={() => { setSize(option); setError(''); setAdded(false); }} aria-pressed={size === option} disabled={!max}>{option}</button>)}</div>{error && <p id="size-error" className="field-error" role="alert">{error}</p>}{requiresSize(product) && <p className="variant-note">{product.category === 'Shoes' ? 'European sizing. Between sizes? We suggest sizing up.' : 'A relaxed, everyday fit. Check the guide for measurements.'}</p>}</div>
      <div className="detail-add-row"><QuantityControl value={quantity} onChange={setQuantity} max={Math.max(1, max)} /><Button onClick={add} disabled={!max} className="flex-1">{!max ? 'Out of stock' : added ? <><Check size={18} />Added to your bag</> : <>Add to bag<span className="add-button-divider" />{formatMoney(product.price * quantity)}</>}</Button></div><div className="detail-perks"><span><Truck size={17} />Free shipping over $150</span><span><RefreshCcw size={16} />30-day demo returns</span></div>
      <div className="detail-accordions"><Accordion title="The little details" defaultOpen><ul>{product.details.map((detail) => <li key={detail}>{detail}</li>)}</ul></Accordion><Accordion title="Materials & care"><p>{product.material}</p><p className="text-xs">Specifications are fictional and provided to demonstrate the product experience.</p></Accordion><Accordion title="Shipping & returns"><p>Standard shipping is $8, or free on orders $150+. Express is $18. Our example returns window is 30 days.</p><p>This is a demo: no physical items are shipped and no payment is taken.</p></Accordion></div><p className="detail-demo-note"><ShieldCheck size={15} />A concept piece. No real payment required.</p>
    </div></div><section className="related-section"><SectionHeading eyebrow="BETTER TOGETHER" title="A few more good things." link="/shop" /><div className="product-grid">{related.map((item, index) => <ProductCard key={item.id} product={item} index={index} />)}</div></section>
    {guideOpen && <Modal title="A good fit, every time." onClose={() => setGuideOpen(false)}><div className="prose-content"><Eyebrow>{product.category === 'Shoes' ? 'EUROPEAN FOOTWEAR GUIDE' : 'CLOTHING SIZE GUIDE'}</Eyebrow><p>{product.category === 'Shoes' ? 'Use your usual European size. If you are between sizes, choose the larger one.' : 'Measurements are body measurements in centimetres, not garment measurements. This style has a relaxed fit.'}</p><table className="size-table"><thead><tr>{(product.category === 'Shoes' ? ['EU', 'UK', 'Foot length (cm)'] : ['Size', 'Chest (cm)', 'Waist (cm)']).map((heading) => <th key={heading}>{heading}</th>)}</tr></thead><tbody>{product.category === 'Shoes' ? [['36', '3.5', '23'], ['37', '4', '23.5'], ['38', '5', '24'], ['39', '6', '25'], ['40', '6.5', '25.5'], ['41', '7.5', '26']].map((row) => <tr key={row[0]}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>) : [['XS', '82–86', '64–68'], ['S', '87–91', '69–73'], ['M', '92–97', '74–79'], ['L', '98–104', '80–86'], ['XL', '105–112', '87–94']].map((row) => <tr key={row[0]}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>)}</tbody></table><p className="text-xs">Illustrative sizing for demonstration only.</p></div></Modal>}
    {imageOpen && <Modal title={product.name} onClose={() => setImageOpen(false)} wide><img className="expanded-product-image" src={product.image} alt={product.alt} /></Modal>}
  </div>;
}
