import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Shop } from './pages/Shop';
import { ProductDetails } from './pages/ProductDetails';
import { CartPage } from './pages/Cart';
import { Checkout } from './pages/Checkout';
import { Confirmation } from './pages/Confirmation';
import { About } from './pages/About';
import { Contact } from './pages/Contact';
import { NotFound } from './pages/NotFound';

export default function App() {
  return <BrowserRouter basename={import.meta.env.BASE_URL}><CartProvider><Routes><Route element={<Layout />}><Route index element={<Home />} /><Route path="shop" element={<Shop />} /><Route path="product/:id" element={<ProductDetails />} /><Route path="cart" element={<CartPage />} /><Route path="checkout" element={<Checkout />} /><Route path="order-confirmation" element={<Confirmation />} /><Route path="about" element={<About />} /><Route path="contact" element={<Contact />} /><Route path="*" element={<NotFound />} /></Route></Routes></CartProvider></BrowserRouter>;
}
