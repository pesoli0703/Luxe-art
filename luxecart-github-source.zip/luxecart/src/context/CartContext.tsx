import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { CART_KEY, availableQuantity, getCartLines, getTotals, lineKey, readCart, sanitizeCart } from '../lib/cart';
import type { CartItem, CartLine, ShippingMethod } from '../lib/cart';
import { getProduct } from '../data/products';
import type { Product } from '../data/products';

type Toast = { id: number; message: string; image?: string; cartLink?: boolean };
type CartContextValue = {
  items: CartItem[]; lines: CartLine[]; count: number; storageWarning: string | null;
  toast: Toast | null; dismissToast: () => void;
  addItem: (product: Product, size: string, color: string, quantity?: number) => boolean;
  updateQuantity: (key: string, quantity: number) => void;
  removeItem: (key: string) => void; clearCart: () => void;
  totals: (method?: ShippingMethod) => ReturnType<typeof getTotals>;
  notify: (message: string) => void;
};
const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(readCart);
  const [items, setItems] = useState<CartItem[]>(initial.items);
  const [storageWarning, setStorageWarning] = useState(initial.warning);
  const [toast, setToast] = useState<Toast | null>(null);
  const notify = useCallback((message: string) => setToast({ id: Date.now(), message }), []);

  useEffect(() => {
    try { localStorage.setItem(CART_KEY, JSON.stringify(items)); }
    catch { setStorageWarning('Your browser is not allowing saved bags. Your bag will work for this visit.'); }
  }, [items]);

  useEffect(() => {
    const sync = (event: StorageEvent) => {
      if (event.key !== CART_KEY && event.key !== null) return;
      try { setItems(event.newValue ? sanitizeCart(JSON.parse(event.newValue)) : []); }
      catch { setItems([]); }
    };
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const addItem = (product: Product, size: string, color: string, quantity = 1) => {
    const max = availableQuantity(product);
    if (!max || !product.sizes.includes(size) || !product.colors.some((c) => c.name === color) || !Number.isInteger(quantity) || quantity < 1) return false;
    const candidate: CartItem = { productId: product.id, size, color, quantity };
    const key = lineKey(candidate);
    const current = items.find((item) => lineKey(item) === key);
    const accepted = Math.min(quantity, max - (current?.quantity ?? 0));
    if (accepted <= 0) { notify(`This option is limited to ${max} per bag. You already have the maximum.`); return false; }
    setItems((previous) => {
      const existing = previous.find((item) => lineKey(item) === key);
      return existing
        ? previous.map((item) => lineKey(item) === key ? { ...item, quantity: Math.min(max, item.quantity + accepted) } : item)
        : [...previous, { ...candidate, quantity: accepted }];
    });
    setToast({ id: Date.now(), message: accepted < quantity ? `${accepted} added — the limit is ${max} for this option.` : `${product.name} added to your bag.`, image: product.image, cartLink: true });
    return true;
  };

  const updateQuantity = (key: string, quantity: number) => {
    if (!Number.isInteger(quantity)) return;
    setItems((previous) => previous.map((item) => {
      if (lineKey(item) !== key) return item;
      const product = getProduct(item.productId);
      return product ? { ...item, quantity: Math.max(1, Math.min(quantity, availableQuantity(product))) } : item;
    }));
  };
  const removeItem = (key: string) => { setItems((previous) => previous.filter((item) => lineKey(item) !== key)); notify('Item removed from your bag.'); };
  const clearCart = () => setItems([]);
  const lines = useMemo(() => getCartLines(items), [items]);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const totals = (method: ShippingMethod = 'standard') => getTotals(items, method);

  return <CartContext.Provider value={{ items, lines, count, storageWarning, toast, dismissToast: () => setToast(null), addItem, updateQuantity, removeItem, clearCart, totals, notify }}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within CartProvider');
  return context;
}
